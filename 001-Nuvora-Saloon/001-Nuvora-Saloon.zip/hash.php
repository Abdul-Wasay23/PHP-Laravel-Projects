<?php
$password = 'NuvoraAdmin@2025';
$hash = password_hash($password, PASSWORD_BCRYPT);
echo $hash;
