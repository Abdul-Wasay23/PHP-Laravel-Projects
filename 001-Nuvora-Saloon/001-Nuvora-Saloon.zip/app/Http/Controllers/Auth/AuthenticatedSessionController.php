<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('pages.login');
    }

    /**
     * Handle an incoming login request.
     */
public function store(Request $request)
{
    $request->validate([
        'email' => ['required','string','email'],
        'password' => ['required','string'],
    ]);

    if (Auth::attempt($request->only('email','password'), $request->filled('remember'))) {
        $request->session()->regenerate();

        // Determine dashboard route based on role
        $redirect = Auth::user()->role_id === 0
            ? route('admin.dashboard')
            : route('user.dashboard');

        if ($request->ajax()) {
            // Return JSON for AJAX login
            return response()->json([
                'success' => true,
                'redirect' => $redirect
            ]);
        }

        // Normal form submission
        return redirect()->intended($redirect);
    }

    // Invalid credentials
    if ($request->ajax()) {
        return response()->json(['error' => 'Invalid credentials'], 422);
    }

    return back()->withErrors([
        'email' => 'The provided credentials do not match our records.',
    ])->onlyInput('email');
}

    
    

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
}
