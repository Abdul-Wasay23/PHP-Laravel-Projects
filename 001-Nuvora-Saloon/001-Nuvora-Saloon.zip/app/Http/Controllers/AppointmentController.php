<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Appointment;
use App\Models\Service;
use App\Models\Barber;
use App\Models\Schedule;
use App\Models\ScheduleOverride;
use Illuminate\Support\Facades\Log;

class AppointmentController extends Controller
{
    // Show booking page
    public function index()
    {
        $services = Service::all();
        $barbers = Barber::all();
        $schedule = Schedule::first();

        $allowedDays = [
            'Mon' => true,
            'Tue' => true,
            'Wed' => true,
            'Thu' => true,
            'Fri' => true,
            'Sat' => false,
            'Sun' => false,
        ];

        if ($schedule) {
            $allowedDays = [
                'Mon' => (bool) $schedule->mon,
                'Tue' => (bool) $schedule->tue,
                'Wed' => (bool) $schedule->wed,
                'Thu' => (bool) $schedule->thu,
                'Fri' => (bool) $schedule->fri,
                'Sat' => (bool) $schedule->sat,
                'Sun' => (bool) $schedule->sun,
            ];
        }

        $overrides = ScheduleOverride::all();

        return view('pages.appointment', [
            'services' => $services,
            'barbers' => $barbers,
            'allowedDays' => $allowedDays,
            'overrides' => $overrides,
        ]);
    }

    // Store appointment
public function store(Request $request)
{
    Log::info("INCOMING APPOINTMENT DATA:", $request->all());

    if (!Auth::check()) {
        return response()->json(['success' => false, 'message' => 'Please login first'], 401);
    }

    // Validate request
    $validated = $request->validate([
        'barber_id' => 'required|exists:barbers,id',
        'services' => 'required|array|min:1',
        'appointment_date' => 'required|date',
        'appointment_time' => 'required|string',
        'total_price' => 'required|numeric|min:0',
        'customer_name' => 'required|string|max:255',
        'notes' => 'nullable|string',
    ]);

    // SAVE APPOINTMENT
    $appointment = Appointment::create([
        'user_id' => Auth::id(),    // ★ ADD THIS ★
        'barber_id' => $validated['barber_id'],
        'customer_name' => $validated['customer_name'],
        'services' => $validated['services'],
        'appointment_date' => $validated['appointment_date'],
        'appointment_time' => $validated['appointment_time'],
        'total_price' => $validated['total_price'],
        'notes' => $validated['notes'],
    ]);

    return response()->json([
        'success' => true,
        'message' => 'Appointment created successfully',
        'appointment_id' => $appointment->id
    ]);
}

    // Cancel appointment by User
    public function cancel(Request $request, $id)
    {
        $appointment = Appointment::where('id', $id)->where('user_id', Auth::id())->first();

        if (!$appointment) {
            return back()->with('error', 'Appointment not found or unauthorized.');
        }

        if ($appointment->status !== 'pending') {
            return back()->with('error', 'Only pending appointments can be cancelled.');
        }

        $appointment->status = 'cancelled';
        $appointment->save();

        return back()->with('success', 'Appointment cancelled successfully.');
    }

    // Show Edit Page
    public function edit($id)
    {
        $appointment = Appointment::where('id', $id)->where('user_id', Auth::id())->first();

        if (!$appointment) {
            return back()->with('error', 'Appointment not found.');
        }

        if ($appointment->status !== 'pending') {
            return back()->with('error', 'You can only edit pending appointments.');
        }

        $barbers = Barber::all();
        $services = Service::all();
        // Decode services if string
        $currentServices = is_string($appointment->services) ? json_decode($appointment->services, true) : $appointment->services;
        $currentServiceIds = collect($currentServices)->pluck('id')->toArray();

        return view('auth.dashboard.user.pages.edit', compact('appointment', 'barbers', 'services', 'currentServiceIds'));
    }

    // Update Appointment
    public function update(Request $request, $id)
    {
         $appointment = Appointment::where('id', $id)->where('user_id', Auth::id())->first();

        if (!$appointment || $appointment->status !== 'pending') {
            return back()->with('error', 'Unable to update appointment.');
        }

        $validated = $request->validate([
            'appointment_date' => 'required|date',
            'appointment_time' => 'required|string',
            'notes' => 'nullable|string',
        ]);

        $appointment->update([
            'appointment_date' => $validated['appointment_date'],
            'appointment_time' => $validated['appointment_time'],
            'notes' => $validated['notes'],
        ]);

        return redirect()->route('user.dashboard')->with('success', 'Appointment updated successfully.');
    }
}
