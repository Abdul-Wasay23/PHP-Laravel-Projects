<?php
namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\ScheduleOverride;
use Illuminate\Http\Request;

class UserScheduleController extends Controller
{
    public function getMonthSchedule($year, $month)
    {
        $schedule = Schedule::first(); // site-wide default
        $overrides = ScheduleOverride::whereYear('date', $year)
                                     ->whereMonth('date', $month)
                                     ->get()
                                     ->keyBy('date'); // index by date

        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $calendar = [];

        for ($d = 1; $d <= $daysInMonth; $d++) {
            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $d);

            if (isset($overrides[$dateStr])) {
                $calendar[$dateStr] = [
                    'is_open' => $overrides[$dateStr]->is_open,
                    'opening_time' => $overrides[$dateStr]->opening_time,
                    'closing_time' => $overrides[$dateStr]->closing_time,
                    'breaks' => $overrides[$dateStr]->breaks ?? [],
                ];
            } else {
                $dayName = date('D', strtotime($dateStr)); // Mon, Tue...
                $calendar[$dateStr] = [
                    'is_open' => in_array($dayName, $schedule->default_working_days) ? 1 : 0,
                    'opening_time' => $schedule->opening_time,
                    'closing_time' => $schedule->closing_time,
                    'breaks' => $schedule->breaks ?? [],
                ];
            }
        }

        return response()->json($calendar);
    }
}
