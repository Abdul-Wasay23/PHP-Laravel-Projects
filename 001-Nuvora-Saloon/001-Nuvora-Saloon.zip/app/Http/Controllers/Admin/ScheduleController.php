<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Log;
use App\Models\Schedule;
use App\Models\ScheduleOverride;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ScheduleController extends Controller
{
    // Save default schedule
    public function store(Request $request)
    {
        Log::info('Schedule store hit', $request->all());

        $schedule = Schedule::first() ?? new Schedule();

        $schedule->opening_time = $request->opening_time;
        $schedule->closing_time = $request->closing_time;
        $schedule->default_working_days = $request->working_days ?? [];
        $schedule->breaks = $request->breaks ?? [];
        $schedule->save();

        Log::info('Schedule saved', $schedule->toArray());

        return response()->json(['success' => true]);
    }

    // Save month overrides
    public function saveOverrides(Request $request)
    {
        Log::info('Save Overrides called', $request->all());

        try {
            foreach ($request->overrides as $date => $data) {
                ScheduleOverride::updateOrCreate(
                    ['date' => $date],
                    [
                        'is_working'   => $data['is_open'],
                        'opening_time' => $data['opening_time'] ?? '09:00',
                        'closing_time' => $data['closing_time'] ?? '18:00',
                        'breaks'       => $data['breaks'] ?? [],
                    ]
                );
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            Log::error('Schedule override save failed: '.$e->getMessage());
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    }

    // Get schedule month
    public function getMonthSchedule($year, $month)
    {
        Log::info("GET MONTH HIT", ['year' => $year, 'month' => $month]);

        $schedule = Schedule::first();

        $overrides = ScheduleOverride::whereYear('date', $year)
                                    ->whereMonth('date', $month)
                                    ->get()
                                    ->keyBy('date');

        $daysInMonth = date('t', strtotime("$year-$month-01"));
        $dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

        $result = [];

        for ($d = 1; $d <= $daysInMonth; $d++) {

            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $d);
            $dayName = $dayNames[date('w', strtotime($dateStr))];

            // Default
            $isWorking = $schedule && in_array($dayName, $schedule->default_working_days ?? []);
            $opening   = $schedule->opening_time ?? '09:00';
            $closing   = $schedule->closing_time ?? '18:00';
            $breaks    = $schedule->breaks ?? [];

            // Override apply
            if (isset($overrides[$dateStr])) {
                $ov = $overrides[$dateStr];

                $isWorking = $ov->is_working;
                $opening   = $ov->opening_time ?? $opening;
                $closing   = $ov->closing_time ?? $closing;
                $breaks    = $ov->breaks ?? [];
            }

            $result[$dateStr] = [
                'is_working'   => $isWorking,
                'opening_time' => $opening,
                'closing_time' => $closing,
                'breaks'       => $breaks
            ];
        }

        return response()->json($result);
    }
}
