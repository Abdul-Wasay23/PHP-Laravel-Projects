<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Barber;

class BarberController extends Controller
{
    // Allowed designation options
    private $designations = ['Owner', 'Stylist', 'Senior'];

    public function index()
    {
        $barbers = Barber::orderBy('id', 'desc')->get();
        return view('auth.dashboard.admin.pages.manage-sections', compact('barbers'));
    }

    public function create()
    {
        // Pass designations to view for dynamic dropdown
        $designations = $this->designations;
        return view('auth.dashboard.admin.pages.barbers.create', compact('designations'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'designation' => 'required|in:' . implode(',', $this->designations),
            'image' => 'nullable|image|max:2048',
        ]);

        $data = $request->all();

        if($request->hasFile('image')){
            $data['image'] = $request->file('image')->store('barbers', 'public');
        }

        Barber::create($data);

        return redirect()->back()->with('success', 'Barber added successfully!');
    }

    public function edit($id)
    {
        $barber = Barber::findOrFail($id);
        $designations = $this->designations;
        return view('auth.dashboard.admin.pages.barbers.edit', compact('barber', 'designations'));
    }

    public function update(Request $request, $id)
    {
        $barber = Barber::findOrFail($id);

        $request->validate([
            'name' => 'required',
            'designation' => 'required|in:' . implode(',', $this->designations),
            'image' => 'nullable|image|max:2048',
        ]);

        $data = $request->all();

        if($request->hasFile('image')){
            $data['image'] = $request->file('image')->store('barbers', 'public');
        }

        $barber->update($data);

        return redirect()->back()->with('success', 'Barber updated successfully!');
    }

    public function destroy($id)
    {
        $barber = Barber::findOrFail($id);
        $barber->delete();

        return redirect()->back()->with('success', 'Barber deleted successfully!');
    }
}
