<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Appointment;

class AdminController extends Controller
{
    public function dashboard(Request $request)
    {
        // Filter by status (optional)
        $status = $request->get('status', 'all');

        $appointments = Appointment::orderBy('appointment_date', 'desc');

        if ($status !== 'all') {
            $appointments->where('status', $status);
        }

        $appointments = $appointments->get();

        return view('admin.dashboard', compact('appointments', 'status'));
    }

    public function searchAppointments(Request $request)
{
    $query = Appointment::with('barber', 'user');

    if ($request->has('user') && !empty($request->user)) {
        $search = $request->user;
        $query->where(function($q) use ($search) {
             $q->where('customer_name', 'like', '%'.$search.'%')
               ->orWhereHas('user', function ($sub) use ($search) {
                   $sub->where('name', 'like', '%'.$search.'%');
               });
        });
    }

    $appointments = $query->orderBy('appointment_date', 'desc')->get();

    // Return JSON for AJAX
    return response()->json([
        'appointments' => $appointments
    ]);
}


public function updateAppointmentStatus(Request $request, $id)
{
    $appointment = Appointment::find($id);

    if (!$appointment) {
        return redirect()->back()->with('error', 'Appointment not found.');
    }

    $appointment->status = $request->status;
    $appointment->save();

    return redirect()->back()->with('success', 'Appointment status updated to ' . ucfirst($appointment->status));
}


}
