<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Schedule;
use App\Models\Service;

class HomeController extends Controller
{
    public function index()
    {
        $services = Service::all();
        $schedule = Schedule::first();

        $days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
        $workingHours = [];

        // Default closed
        foreach ($days as $day) {
            $workingHours[$day] = 'Closed';
        }

        // Break text (only once)
        $breakText = '';

        if ($schedule) {

            // Prepare break text once
            if (!empty($schedule->breaks)) {
                foreach ($schedule->breaks as $b) {
                    $breakText .= "{$b['start']} - {$b['end']}, ";
                }
                $breakText = rtrim($breakText, ', ');
            }

            // Prepare working days
            $defaultDays = $schedule->default_working_days ?? [];

            foreach ($days as $day) {
                if (in_array($day, $defaultDays)) {

                    $opening = $schedule->opening_time ?? '09:00';
                    $closing = $schedule->closing_time ?? '18:00';

                    // Working hours WITHOUT break
                    $workingHours[$day] = $opening . ' - ' . $closing;
                }
            }
        }

        return view('pages.index', compact('services', 'workingHours', 'breakText'));
    }
}
