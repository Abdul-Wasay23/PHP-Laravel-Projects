<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ScheduleOverride extends Model
{
    protected $fillable = [
        'date',
        'is_open',
        'opening_time',
        'closing_time',
        'breaks',
    ];

    protected $casts = [
        'breaks' => 'array',
    ];
}
