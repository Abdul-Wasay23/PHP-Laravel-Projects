<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    protected $fillable = [
        'opening_time',
        'closing_time',
        'default_working_days',
        'breaks',
    ];

    protected $casts = [
        'default_working_days' => 'array',
        'breaks' => 'array',
    ];

    // Set default values for new schedule entries
    protected $attributes = [
        'default_working_days' => '[]',
        'breaks' => '[]',
    ];

    /**
     * Check if a given day is a working day
     */
    public function isWorkingDay(string $day): bool
    {
        return in_array($day, $this->default_working_days ?? []);
    }

    /**
     * Get breaks for a day (could be extended for overrides)
     */
    public function getBreaks(): array
    {
        return $this->breaks ?? [];
    }
}
