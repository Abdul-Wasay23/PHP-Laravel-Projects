<!-- inner-banner start -->
<section class="banner_sec inner-banner">
  <div class="banner-box">
    <div class="container">
      <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
          <div class="banner_text tilt" data-tilt>
            <h1>{{ $title ?? 'Page Title' }}</h1>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- inner-banner start -->
