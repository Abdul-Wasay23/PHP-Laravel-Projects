@props(['workingHours', 'breakText'])

<!-- section hour-sec start -->
<section class="hour-sec sec">
  <div class="container">
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-10 col-12 p-0">
        <div class="hour-card">
          <div class="hour-card-image">
            <video class="hour-video" src="{{ asset('images/haircut.mp4') }}"></video>
            <a href="#" class="play-pause">
              <i class="fa-solid fa-play"></i>
              <i class="fa-solid fa-pause"></i>
            </a>
          </div>
          <div class="hour-card-text">
            <h3 data-aos="fade-up" data-aos-offset="200" data-aos-duration="1000">
              Complimentary Cold Beverage <br />
              & Hot Towels
            </h3>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-lg-6 col-md-6 col-sm-10 col-12 p-0">
        <div class="hour-right-box">
          
          <h6 data-aos="zoom-out-left" data-aos-offset="200" data-aos-duration="1000">
            CALL NOW - (189 983 837 1)
          </h6>

          <h2 data-aos="zoom-out-left" data-aos-offset="200" data-aos-duration="1000">
            WORKING HOURS
          </h2>

          {{-- Break show only once --}}
          @if($breakText)
            <p class="break-line" data-aos="zoom-out-left" data-aos-offset="200" data-aos-duration="1000">
              Break Timing : {{ $breakText }}
            </p>
          @endif

          <ul class="hour-list">
            @foreach($workingHours as $day => $time)
              <li data-aos="zoom-out-left" data-aos-offset="200" data-aos-duration="1000">
                <p>{{ $day }}</p>
                <p class="{{ $time === 'Closed' ? 'closed' : '' }}">{{ $time }}</p>
              </li>
            @endforeach
          </ul>

        </div>
      </div>

    </div>
  </div>
</section>
<!-- section hour-sec end -->
