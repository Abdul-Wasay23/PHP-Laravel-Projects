@guest
    <script>window.location.href = "{{ route('login') }}";</script>
@endguest

@php
$allowedDays = array_keys($allowedDays ?? ['Mon'=>true,'Tue'=>true,'Wed'=>true,'Thu'=>true,'Fri'=>true]);
$allowedDays = $allowedDays ?? ['Mon','Tue','Wed','Thu','Fri'];
$services = \App\Models\Service::all();
$barbers = \App\Models\Barber::all();
@endphp

<meta name="csrf-token" content="{{ csrf_token() }}">

<section class="appointment-section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="saloon-booking" id="saloonBooking">
          
          <!-- HEADER -->
          <div class="sb-header">
            <div class="sb-title">
              <div class="sb-brand">Nuvora Salon</div>
            </div>

            <div class="sb-steps">
              <div class="progress-steps">
                <div class="step" data-step="1">
                  <span class="label">1. Service</span>
                  <div class="bar"></div>
                </div>
                <div class="step" data-step="2">
                  <span class="label">2. Time</span>
                  <div class="bar"></div>
                </div>
                <div class="step" data-step="3">
                  <span class="label">3. Details</span>
                  <div class="bar"></div>
                </div>
                <div class="step" data-step="4">
                  <span class="label">4. Done</span>
                  <div class="bar"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- BODY -->
          <div class="sb-body">
            <div class="sb-left">

              <!-- STEP 1 -->
              <div class="step-panel" data-panel="1">
                <div class="card-section">
                    <h3>Choose a service</h3>
                    <div class="service-list" id="serviceList">
                        @forelse($services as $service)
                            <div class="svc" 
                                data-id="{{ $service->id }}"
                                data-duration="{{ $service->hours }}" 
                                data-price="{{ $service->price }}">
                                <div>
                                    <!-- Service Image -->
                                    <div class="svc-image mb-2">
                                        <img src="{{ $service->image ? asset('storage/'.$service->image) : asset('images/default-image.png') }}" 
                                            alt="{{ $service->title }}" width="10" class="step-img">
                                    </div>

                                    <div class="svc-title">{{ $service->title }}</div>
                                    <div class="svc-time">{{ $service->hours }} Mins · ${{ $service->price }}</div>
                                </div>
                            </div>
                        @empty
                            <div class="col-12 text-center">
                                <p class="text-muted m-0">Nothing to show</p>
                            </div>
                        @endforelse
                    </div>
                </div>

                <div class="card-section">
                  <h3>Pick a barber</h3>
                  <div class="barber-list" id="barberList">
                      @forelse($barbers as $barber)
                          <div class="barber" 
                              data-id="{{ $barber->id }}" 
                              data-price="{{ $barber->extra_price ?? 0 }}" 
                              data-name="{{ $barber->name }}" 
                              data-img="{{ $barber->image ? asset('storage/'.$barber->image) : asset('images/default-barber.png') }}"
                              data-designation="{{ $barber->designation }}">
                              <img src="{{ $barber->image ? asset('storage/'.$barber->image) : asset('images/default-barber.png') }}" 
                                  alt="{{ $barber->name }}">
                                  
                              <div class="meta">
                                  <h5>{{ $barber->name }}</h5>
                                  <p>{{ $barber->designation }}</p>
                              </div>
                          </div>
                      @empty
                          <div class="col-12 text-center">
                              <p class="text-muted m-0">No barbers available</p>
                          </div>
                      @endforelse
                  </div>
              </div>

                <div class="sb-actions">
                  <button class="theme-btn" id="toStep2">Next</button>
                </div>
              </div>

              <!-- STEP 2 -->
              <div class="step-panel" data-panel="2">
                <div class="card-section">
                <h3>Choose Date & Time</h3>
                <div class="calendar">
                  <div class="cal-left">
                    <div class="cal-header">
                      <div class="cal-title"><strong id="calMonthLabel">October 2025</strong></div>
                      <div class="cal-nav">
                        <button id="prevMonth">&lt;</button>
                        <button id="nextMonth">&gt;</button>
                      </div>
                    </div>

                    <div class="cal-weekdays">
                      <div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div><div>Sun</div>
                    </div>

                    <div class="cal-grid" id="calendarGrid"></div>
                  </div>

                  <div class="cal-right">
                    <h4>Available time slots</h4>
                    <div class="time-slots" id="timeSlots"></div>
                  </div>
                </div>
                </div>


                <div class="sb-actions">
                  <button class="btn btn--secondary theme-btn" id="backTo1">Previous</button>
                  <button class="theme-btn" id="toStep3">Next</button>
                </div>
              </div>

              <!-- STEP 3 -->
              <div class="step-panel" data-panel="3">
              <div class="card-section">
                <h3>Your details</h3>
                <div class="form-grid">
                  <input id="inputName" name="name" placeholder="Full name" class="form-input" value="{{ Auth::check() ? Auth::user()->name : '' }}" required readonly />
                  <input id="inputPhone" placeholder="Phone" class="form-input short" />
                  <input id="inputEmail" placeholder="Email" class="form-input" value="{{ Auth::check() ? Auth::user()->email : '' }}" required readonly />
                </div>
              </div>

              <div class="card-section">
                <h3>Notes (optional)</h3>
                <textarea id="inputNotes" rows="4" class="form-textarea"></textarea>
              </div>

              <div class="sb-actions">
                <button class="btn btn--secondary theme-btn" id="backTo2">Previous</button>
                <button class="theme-btn" id="confirmBooking">Confirm</button>
              </div>
            </div>

              <!-- STEP 4 -->
              <div class="step-panel" data-panel="4">
                <div class="done">
                  <div class="tick">✓</div>
                  <h2>Request Sent</h2>
                  <p class="done-text">Your booking request has been sent. Once the salon confirms, you will receive a confirmation message here.</p>
                  <div class="done-actions">
                    <button class="theme-btn" id="goNew">Book another</button>
                    <a href="{{ url('/') }}" class="btn btn--secondary theme-btn">Back to Home</a>
                  </div>
                </div>
              </div>
            </div>

            <!-- RIGHT SUMMARY (STATIC VERSION) -->
            <aside class="sb-right" id="style-6">
            <div class="summary">
                <h4>Summary</h4>

                <div class="summary-box">
                  <div id="summaryServices"></div>
                </div>

                <div class="summary-box mt-3">
                  <div id="summaryBarber"></div>
                </div>

                <div class="summary-row flex-column" id="summaryDateTime">
                <!-- Here will be current date and time -->
                </div>

                <div class="summary-divider"></div>

                <div class="summary-row total">
                  <div>Total</div>
                  <div id="summaryTotal"></div>
                </div>
            </div>
            </aside>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
// This js is for booking appointment (Start)
document.getElementById('confirmBooking')?.addEventListener('click', async () => {

    try {
        // Collect selected services
        const selectedServices = Array.from(document.querySelectorAll('.svc.active')).map(svc => ({
            id: svc.dataset.id,
            name: svc.querySelector('.svc-title').innerText,
            duration: Number(svc.dataset.duration),
            price: Number(svc.dataset.price)
        }));

        // Collect selected barber
        const barberEl = document.querySelector('.barber.active');

        // Collect selected date and time
        const selectedDay = document.querySelector('.cal-day.selected');
        const selectedTime = document.querySelector('.slot.selected');

        // Validations
        if (!barberEl) return alert("Please select a barber.");
        if (selectedServices.length === 0) return alert("Please select at least one service.");
        if (!selectedDay) return alert("Please select a date.");
        if (!selectedTime) return alert("Please select a time slot.");

        // Build appointment date from dataset
          const year = selectedDay.dataset.year;
          const month = selectedDay.dataset.month;
          const day = selectedDay.innerText;

        // Calculate total price
        const totalPrice = Number(
            document.getElementById('summaryTotal')?.innerText.replace('$', '') ||
            selectedServices.reduce((sum, s) => sum + s.price, 0)
        );

        // Prepare payload
        const payload = {
            barber_id: barberEl.dataset.id,
            services: selectedServices,
            appointment_date: `${year}-${month}-${day}`,
            appointment_time: selectedTime.innerText,
            total_price: totalPrice,
            customer_name: document.getElementById('inputName')?.value || '', 
            notes: document.getElementById('inputNotes')?.value || ''
        };

        // Send POST request
        const res = await fetch('/appointments/store', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify(payload)
        });

        const result = await res.json();

        if (!res.ok || !result.success) {
            return alert(result.message || "Booking failed. Please try again.");
        }

        // Show success panel
        document.querySelectorAll('.step-panel').forEach(p => p.style.display = 'none');
        document.querySelector('.step-panel[data-panel="4"]').style.display = 'block';

        // Reset UI
        document.querySelectorAll('.svc.active, .barber.active, .cal-day.selected, .slot.selected')
            .forEach(el => el.classList.remove('active', 'selected'));

        document.getElementById('inputNotes').value = '';
        document.getElementById('summaryServices').innerHTML = '';
        document.getElementById('summaryBarber').innerHTML = '';
        document.getElementById('summaryDateTime').innerHTML = '';
        document.getElementById('summaryTotal').innerText = '$0';

    } catch (err) {
        console.error("Appointment booking error:", err);
        alert("An unexpected error occurred. Please try again.");
    }
});

// This js is for booking appointment (End)


// This js is for summary total (Start)
function updateSummaryTotal() {
    const totalEl = document.getElementById('summaryTotal');
    if (!totalEl) return;

    const servicesTotal = Array.from(document.querySelectorAll('.svc.active'))
        .reduce((sum, svc) => sum + Number(svc.dataset.price || 0), 0);

    const barber = document.querySelector('.barber.active');
    const barberExtra = barber ? Number(barber.dataset.price || 0) : 0;

    totalEl.textContent = `$${(servicesTotal + barberExtra).toFixed(2)}`;
}
// This js is for summary total (End)


// This js is for summary date and time (Start)
function updateSummaryDateTime() {
    const dateRow = document.querySelector('#summaryDateTime');
    if (!dateRow) return;

    const now = new Date();
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    const formattedDate = now.toLocaleDateString('en-US', options);
    const formattedTime = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

    dateRow.innerHTML = `
        <div class="d-flex justify-content-between w-100">
            <small>Date</small>
            <div class="summary-value">${formattedDate}</div>
        </div>
        <div class="d-flex justify-content-between w-100">
            <small>Time</small>
            <div class="summary-value">${formattedTime}</div>
        </div>
    `;
}
// This js is for summary date and time (End)


// This js is for summary services (Start)
function updateSummaryServices() {
    const container = document.getElementById('summaryServices');
    const selectedServices = document.querySelectorAll('.svc.active');

    const heading = selectedServices.length > 0 ? 'Selected Services' : 'Nothing Selected';
    container.innerHTML = `<h6 class="mb-2">${heading}</h6>`;

    selectedServices.forEach(svc => {
        const name = svc.querySelector('.svc-title').innerText;
        const duration = svc.dataset.duration;
        const price = svc.dataset.price;

        container.innerHTML += `
            <div class="summary-row flex-column mb-2">
                <div class="summary-row-inner">
                    <small>Service Name</small>
                    <div class="summary-value">${name}</div>
                </div>
                <div class="summary-row-inner">
                    <small>Time Duration</small>
                    <div class="summary-value">${duration} min</div>
                </div>
                <div class="summary-row-inner">
                    <small>Price</small>
                    <div class="summary-value">${price}</div>
                </div>
            </div>
        `;
    });

    updateSummaryTotal();
}
// This js is for summary services (End)


// This js is for summary barber (Start)
function updateSummaryBarber() {
    const container = document.getElementById('summaryBarber');
    const barber = document.querySelector('.barber.active');

    const heading = barber ? 'Selected Barber' : 'Nothing Selected';
    container.innerHTML = `<h6 class="mb-2">${heading}</h6>`;

    if (!barber) return;

    const name = barber.dataset.name;
    const img = barber.dataset.img;
    const designation = barber.dataset.designation || '';

    container.innerHTML += `
        <div class="summary-row">
            <div>
                <div class="summary-value">${name}</div>
                <div class="summary-value">${designation}</div>
            </div>
            <img src="${img}" class="barber-pic" alt="${name}">
        </div>
    `;

    updateSummaryTotal(); // Update total when barber changes
}
// This js is for summary barber (End)


// This js is for adding active class to services (Start)
document.querySelectorAll('.svc').forEach(el =>
    el.addEventListener('click', e => {
        el.classList.toggle('active');
        updateSummaryServices();
    })
);
// This js is for adding active class to services (End)


// This js is for adding active class to barber (Start)
document.querySelectorAll('.barber').forEach(el =>
    el.addEventListener('click', () => {
        document.querySelectorAll('.barber').forEach(x => x.classList.remove('active'));
        el.classList.add('active');
        updateSummaryBarber();
    })
);
// This js is for adding active class to barber (End)


// This js is for allowed days (Start)
const allowedDays = @json($allowedDays);
console.log('allowedDays:', allowedDays);
// This js is for allowed days (End)


// This js is for progress steps & navigation (Start)
(function () {
    const stepsEls = document.querySelectorAll('.progress-steps .step');

    function updateProgress(step) {
        stepsEls.forEach(s => {
            const n = Number(s.getAttribute('data-step'));
            s.classList.remove('active', 'complete');
            if (step > n) s.classList.add('complete');
            if (step === n) s.classList.add('active');
        });

        document.querySelectorAll('.step-panel').forEach(p => {
            p.style.display = Number(p.getAttribute('data-panel')) === step ? 'block' : 'none';
        });
    }

    let currentStep = 1;
    updateProgress(currentStep);

    // Navigation buttons
    const navMap = { 'toStep2': 2, 'backTo1': 1, 'toStep3': 3, 'backTo2': 2, 'confirmBooking': 4 };
    Object.keys(navMap).forEach(id => {
        document.getElementById(id)?.addEventListener('click', () => {
            currentStep = navMap[id];
            updateProgress(currentStep);
        });
    });

    document.getElementById('goNew')?.addEventListener('click', () => {
        // Reset state variables
        currentStep = 1;
        updateProgress(currentStep);
        
        // Reset UI Elements
        document.querySelectorAll('.svc.active, .barber.active, .cal-day.selected, .slot.selected')
            .forEach(el => el.classList.remove('active', 'selected'));

        const notesEl = document.getElementById('inputNotes');
        if(notesEl) notesEl.value = '';

        document.getElementById('summaryServices').innerHTML = '';
        document.getElementById('summaryBarber').innerHTML = '';
        document.getElementById('summaryDateTime').innerHTML = '';
        document.getElementById('summaryTotal').innerText = '$0';
        
        // Re-initialize summary
        updateSummaryDateTime(); 
    });
})();
// This js is for progress steps & navigation (End)


// This js is for calendar (Start)
(async function () {
    const calendarGrid = document.getElementById('calendarGrid');
    const calMonthLabel = document.getElementById('calMonthLabel');
    const timeSlotsContainer = document.getElementById('timeSlots');
    let current = new Date();

    async function fetchMonthSchedule(year, month) {
        try {
            const res = await fetch(`/schedule/month/${year}/${month}`);
            if (!res.ok) throw new Error('Network error');
            return await res.json();
        } catch (err) {
            console.error('Error fetching schedule:', err);
            return {};
        }
    }

    async function drawCalendar(date) {
        if (!calendarGrid) return;
        calendarGrid.innerHTML = '';
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        calMonthLabel.innerText = date.toLocaleString(undefined, { month: 'long', year: 'numeric' });
        const scheduleData = await fetchMonthSchedule(year, month);

        const firstDay = new Date(year, month - 1, 1);
        const startWeekday = (firstDay.getDay() + 6) % 7;
        const daysInMonth = new Date(year, month, 0).getDate();

        // Fill empty cells before month start
        for (let i = 0; i < startWeekday; i++) {
            const el = document.createElement('div');
            el.className = 'cal-day cal-day--muted';
            calendarGrid.appendChild(el);
        }

        // Month days
        for (let d = 1; d <= daysInMonth; d++) {
            const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
            const dayInfo = scheduleData[dateStr];
            const weekdayName = new Date(year, month - 1, d).toLocaleString('en-US', { weekday: 'short' });

            const el = document.createElement('div');
            el.className = 'cal-day';
            el.innerText = d;
            
            el.dataset.year = year;
            el.dataset.month = String(month).padStart(2, '0');

            if (!allowedDays.includes(weekdayName) || !dayInfo?.is_working) {
                el.classList.add('unavailable');
                el.title = 'Closed';
                calendarGrid.appendChild(el);
                continue;
            }

            el.classList.add('available');
            el.title = `Open: ${dayInfo.opening_time} - ${dayInfo.closing_time}`;

            el.addEventListener('click', () => {
                if (!dayInfo?.is_working) {
                    alert('No availability on this date.');
                    return;
                }
                document.querySelectorAll('.cal-day').forEach(x => x.classList.remove('selected'));
                el.classList.add('selected');
                loadTimeSlots(dayInfo);
            });

            calendarGrid.appendChild(el);
        }

        // Fill trailing empty cells
        const remainder = calendarGrid.children.length % 7;
        if (remainder) {
            for (let i = 0; i < 7 - remainder; i++) {
                const el = document.createElement('div');
                el.className = 'cal-day cal-day--muted';
                calendarGrid.appendChild(el);
            }
        }
    }

    function loadTimeSlots(dayInfo) {
        if (!timeSlotsContainer || !dayInfo?.is_working) return;
        timeSlotsContainer.innerHTML = '';
        let [h, m] = dayInfo.opening_time.split(':').map(Number);
        const [ch, cm] = dayInfo.closing_time.split(':').map(Number);
        const breaks = dayInfo.breaks || [];

        while (h < ch || (h === ch && m < cm)) {
            const slotStr = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
            if (!breaks.some(b => slotStr >= b.start && slotStr < b.end)) {
                const el = document.createElement('div');
                el.className = 'slot available';
                el.innerText = slotStr;
                el.addEventListener('click', () => {
                    document.querySelectorAll('.slot').forEach(x => x.classList.remove('selected'));
                    el.classList.add('selected');
                });
                timeSlotsContainer.appendChild(el);
            }
            m += 30;
            if (m >= 60) { m -= 60; h++; }
        }
    }

    // Month navigation
    document.getElementById('prevMonth')?.addEventListener('click', () => {
        current = new Date(current.getFullYear(), current.getMonth() - 1, 1);
        drawCalendar(current);
    });
    document.getElementById('nextMonth')?.addEventListener('click', () => {
        current = new Date(current.getFullYear(), current.getMonth() + 1, 1);
        drawCalendar(current);
    });

    drawCalendar(current);
})();
// This js is for calendar (End)


// This js is for initialization (Start)
updateSummaryServices();
updateSummaryBarber();
updateSummaryDateTime();
setInterval(updateSummaryDateTime, 60000); // update time every minute
// This js is for initialization (End)

</script>
