@php
$services = \App\Models\Service::orderBy('id', 'desc')->take(6)->get(); // only latest 6 services
@endphp

<section class="price-sec sec">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="grid-heading gallery-heading text-center">
          <h2 data-aos="fade-up" data-aos-offset="200" data-aos-duration="1000">
            PRICE TABLE
          </h2>
          <h6 data-aos="fade-up" data-aos-offset="200" data-aos-duration="1000">
            Get Your BEARD
          </h6>
          <div class="scissor-design" data-aos="fade-up" data-aos-offset="200" data-aos-duration="1000">
            <img src="{{ asset('images/scissor.png') }}" alt="scissor" class="scissor-img" />
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center">
        @if($services->isEmpty())
            <div class="col-12 text-center mt-4">
                <h2 class="text-muted">Nothing to show now</h2>
            </div>
        @else
            @foreach($services as $service)
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-10 col-12">
                    <div class="price-card" 
                         data-aos="{{ $loop->iteration % 2 == 0 ? 'zoom-out-left' : 'zoom-out-right' }}" 
                         data-aos-duration="1000" data-aos-offset="200">
                        
                        <div class="price-card-text">
                            <h5>{{ $service->title }}</h5>
                            <p>{{ $service->description }}</p>
                        </div>

                        <div class="price-card-price">
                            <h5>${{ number_format($service->price, 2) }}</h5>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif
    </div>
  </div>
</section>
