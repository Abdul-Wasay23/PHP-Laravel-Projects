@extends('layouts.app')

@section('title', 'Gallery - Nuvora Saloon')

@section('content')

  <!-- Inner Banner -->
  <x-section-inner-banner title="Gallery" />
  <!-- Inner Banner End -->

  <!-- section price-sec start -->
  <x-section-gallery />
  <!-- section price-sec end  -->

@endsection
