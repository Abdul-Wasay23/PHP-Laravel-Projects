@extends('layouts.app')

@section('title', 'Contact Us - Nuvora Saloon')

@section('content')

  <!-- Inner Banner -->
  <x-section-inner-banner title="Contact Us" />

  <!-- Contact Section -->
  <x-section-contact />

@endsection
