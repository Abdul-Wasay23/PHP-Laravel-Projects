@extends('layouts.app')

@section('title', 'Login - Nuvora Saloon')

@section('content')

  <!-- Inner Banner -->
  <x-section-inner-banner title="Login / Register" />

  <!-- Login Section -->
  <x-section-login />

@endsection
