@extends('layouts.app')

@section('title', 'Appointment - Nuvora Saloon')

@section('content')

    <!-- Inner Banner -->
    <x-section-inner-banner title="Book Appointment" />

<x-section-appointment :allowed-days="$allowedDays" :services="$services" :barbers="$barbers" :overrides="$overrides"/>



@endsection
