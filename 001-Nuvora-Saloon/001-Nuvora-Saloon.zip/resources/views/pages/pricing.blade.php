@extends('layouts.app')

@section('title', 'Pricing / Packages - Nuvora Saloon')

@section('content')

  <!-- Inner Banner -->
  <x-section-inner-banner title="Pricing / Packages" />
  <!-- Inner Banner End -->

  <!-- section price-sec start -->
  <x-section-inner-price />
  <!-- section price-sec end  -->

@endsection
