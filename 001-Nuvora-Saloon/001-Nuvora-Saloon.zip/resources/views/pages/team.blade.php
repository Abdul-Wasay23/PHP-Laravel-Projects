@extends('layouts.app')

@section('title', 'Our Team - Nuvora Saloon')

@section('content')

  <!-- Inner Banner -->
  <x-section-inner-banner title="Our Team" />
  <!-- Inner Banner End -->

  <!-- section price-sec start -->
  <x-section-inner-barber />
  <!-- section price-sec end  -->

@endsection
