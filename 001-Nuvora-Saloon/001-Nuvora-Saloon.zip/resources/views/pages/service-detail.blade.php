@extends('layouts.app')

@section('title', 'Service Detail - Nuvora Saloon')

@section('content')

    <!-- Inner Banner -->
    <x-section-inner-banner title="Service Detail" />

    <x-section-service-detail />

@endsection
