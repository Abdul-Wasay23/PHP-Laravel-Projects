@extends('layouts.app')

@section('title', 'User Dashboard') 

@section('content')

    @include('auth.dashboard.user.components.banner-dashboard')


    <!-- section dashboard-main-sec start -->
    <section class="dashboard-main-sec sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="dashboard-left-box">
                        <div class="dashboard-left-detail">
                            <div class="dashboard-left-detail-image">
                            <img src="{{ asset('images/pattern.jpg') }}" alt="pattern-img" class="pattern-img">
                            </div>
                            <div class="dashboard-left-detail-text">
                                <h3>User Dashboard</h3>
                               <a href="mailto:{{ Auth::user()->email }}">{{ Auth::user()->email }}</a>                          
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit" class="theme-btn">Sign Out</button>
                                </form>
                            </div>
                        </div>                    
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="dashboard-right-box">
                        <h3>My Appointments</h3>
                        
                        @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                           {{ session('success') }}
                           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        @endif
                        @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                           {{ session('error') }}
                           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        @endif

                        <div class="table-responsive custom-table-wrapper">
                            <table class="table table-bordered table-striped custom-table">
                                <thead>
                                    <tr>
                                        <th>Barber</th>
                                        <th>Services</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($appointments as $app)
                                    <tr>
                                        <td>{{ $app->barber->name }}</td>
                                        <td>
                                            @php
                                            $services = is_array($app->services) ? $app->services : json_decode($app->services, true);
                                            @endphp
                                            @foreach($services as $svc)
                                            {{ $svc['name'] }} (${{ $svc['price'] }})<br>
                                            @endforeach
                                        </td>
                                        <td>{{ $app->appointment_date }}</td>
                                        <td>{{ $app->appointment_time }}</td>
                                        <td>${{ $app->total_price }}</td>
                                        <td>
                                            @if($app->status == 'pending')
                                                <span class="badge bg-warning text-dark">Pending</span>
                                            @elseif($app->status == 'confirmed')
                                                <span class="badge bg-success">Confirmed</span>
                                            @elseif($app->status == 'completed')
                                                <span class="badge bg-primary">Completed</span>
                                            @elseif($app->status == 'cancelled')
                                                <span class="badge bg-danger">Cancelled</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if($app->status == 'pending')
                                            <!-- Edit Button -->
                                            <a href="{{ route('user.appointments.edit', $app->id) }}" class="theme-btn sm-btn btn-warning" style="display:inline-block; padding: 5px 15px; font-size:14px; margin-right:5px;">Edit</a>
                                            <!-- Cancel Button -->
                                            <form action="{{ route('user.appointments.cancel', $app->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                <button type="submit" class="theme-btn sm-btn black-btn" style="display:inline-block; padding: 5px 15px; font-size:14px; background:#141414; border:none;" onclick="return confirm('Are you sure you want to cancel?')">Cancel</button>
                                            </form>
                                            @else
                                            <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="7" class="text-center">No appointments found.</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section dashboard-main-sec end  -->
@endsection
