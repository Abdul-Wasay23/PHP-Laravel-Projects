@extends('layouts.app')

@section('title', 'Edit Appointment')

@section('content')



<!-- dashboard banner start -->
<section class="banner_sec inner-banner">
  <div class="banner-box">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="banner_text tilt" data-tilt>
            <h1>
              Welcome to your dashboard! 
            </h1>
          </div>          
        </div>
      </div>
    </div>
  </div>
</section>
<!-- dashboard banner end -->




<div class="container py_8">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h3 class="mb-0 text-white">Edit Appointment</h3>
                </div>
                <div class="card-body">
                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif

                    <form action="{{ route('user.appointments.update', $appointment->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label class="form-label">Barber: <strong>{{ $appointment->barber->name }}</strong></label>
                            <p class="text-muted small">Barber cannot be changed during update.</p>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="appointment_date" class="form-control" value="{{ $appointment->appointment_date }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Time</label>
                            <input type="time" name="appointment_time" class="form-control" value="{{ $appointment->appointment_time }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3">{{ $appointment->notes }}</textarea>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="{{ route('user.dashboard') }}" class="theme-btn sm-btn black-btn" style="background:#141414;">Cancel</a>
                            <button type="submit" class="theme-btn sm-btn">Update Appointment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
