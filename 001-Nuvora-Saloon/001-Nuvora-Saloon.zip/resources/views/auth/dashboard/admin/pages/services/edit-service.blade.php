@extends('layouts.app')

@section('title', 'Edit Service') 

@section('content')

    <!-- Banner -->
    @include('auth.dashboard.admin.components.banner-dashboard')

    {{-- Alerts container --}}
    <div class="alert-container">

        {{-- Success --}}
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- Error --}}
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- Validation errors --}}
        @if($errors->any())
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Please fix the following:</strong>
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

    </div>

    <div class="dashboard-main-sec sec">
        <div class="container">
            <h2 class="black">Edit Service</h2>

            <form action="{{ route('admin.services.update', $service->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label for="title" class="form-label">Service Title</label>
                    <input type="text" name="title" id="title" class="form-control" value="{{ old('title', $service->title) }}">
                    @error('title')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Service Description</label>
                    <textarea name="description" id="description" class="form-control">{{ old('description', $service->description) }}</textarea>
                    @error('description')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>


                <!-- New fields for price and hours -->
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" step="0.01" name="price" id="price" class="form-control" value="{{ old('price', $service->price) }}" required>
                    @error('price')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="hours" class="form-label">Duration Hours (In Mins)</label>
                    <input type="number" name="hours" id="hours" class="form-control" value="{{ old('hours', $service->hours) }}" required>
                    @error('hours')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>

                        <div class="mb-3">
                        <label class="form-label">Service Image</label>

                        <div class="drop-area" data-preview-id="imagePreview1" 
                            style="border: 2px dashed #ccc; padding: 20px; text-align:center; cursor:pointer;">
                            <p>Drag & Drop image here or click to select</p>
                            <input type="file" name="image" class="file-input" style="display:none;">
                            <img id="imagePreview1" 
                                src="{{ isset($service) && $service->image ? asset('storage/' . $service->image) : '#' }}" 
                                alt="Preview" 
                                style="max-height:150px; margin-top:10px; display:{{ isset($service) && $service->image ? 'block' : 'none' }}">
                        </div>

                        @error('image')
                            <div class="text-danger">{{ $message }}</div>
                        @enderror
                    </div>


                <div class="d-flex gap-10">
                    <button type="submit" class="theme-btn sm-btm">Update Service</button>
                    <a href="{{ route('admin.services.index') }}" class="theme-btn sm-btm black-btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>

@endsection
