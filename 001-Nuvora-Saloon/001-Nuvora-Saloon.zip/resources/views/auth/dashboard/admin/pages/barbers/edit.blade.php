@extends('layouts.app')

@section('title', 'Edit Barber')

@section('content')
@include('auth.dashboard.admin.components.banner-dashboard')

    {{-- Alerts container --}}
    <div class="alert-container">

        {{-- Success --}}
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- Error --}}
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- Validation errors --}}
        @if($errors->any())
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Please fix the following:</strong>
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

    </div>

<section class="dashboard-main-sec sec">
    <div class="container">
        <h3>Edit Barber</h3>

        <form action="{{ route('admin.barbers.update', $barber->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" class="form-control" value="{{ $barber->name }}">
            </div>

            <div class="mb-3">
                <label>Designation</label>
                <select name="designation" class="form-control">
                    <option value="">Select Designation</option>
                    <option value="Owner" {{ $barber->designation == 'Owner' ? 'selected' : '' }}>Owner</option>
                    <option value="Stylist" {{ $barber->designation == 'Stylist' ? 'selected' : '' }}>Stylist</option>
                    <option value="Senior" {{ $barber->designation == 'Senior' ? 'selected' : '' }}>Senior</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Facebook URL</label>
                <input type="text" name="facebook" class="form-control" value="{{ $barber->facebook }}">
            </div>

            <div class="mb-3">
                <label>Twitter URL</label>
                <input type="text" name="twitter" class="form-control" value="{{ $barber->twitter }}">
            </div>

            <div class="mb-3">
                <label>Instagram URL</label>
                <input type="text" name="instagram" class="form-control" value="{{ $barber->instagram }}">
            </div>

                <div class="mb-3">
                    <label class="form-label">Barber Image</label>

                    <div class="drop-area" data-preview-id="barberImagePreview" 
                        style="border: 2px dashed #ccc; padding: 20px; text-align:center; cursor:pointer;">
                        <p>Drag & Drop image here or click to select</p>
                        <input type="file" name="image" class="file-input" style="display:none;">
                        <img id="barberImagePreview" 
                            src="{{ isset($barber) && $barber->image ? asset('storage/' . $barber->image) : '#' }}" 
                            alt="Preview" 
                            style="max-height:150px; margin-top:10px; display:{{ isset($barber) && $barber->image ? 'block' : 'none' }}">
                    </div>

                    @error('image')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>


            <button class="theme-btn">Update Barber</button>
        </form>
    </div>
</section>
@endsection
