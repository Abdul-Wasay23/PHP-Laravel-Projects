<!-- <header class="dashboard-header p-3 mb-3 border-bottom">
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="m-0">Admin Dashboard</h4>

        <form action="#" method="POST">
            @csrf
            <button class="btn btn-danger btn-sm">Logout</button>
        </form>
    </div>
</header> -->
