<div class="dashboard-left-box">
  <div class="dashboard-left-detail">
    <div class="dashboard-left-detail-image">
        <img src="{{ asset('images/pattern.jpg') }}" alt="pattern-img" class="pattern-img">
    </div>
    <div class="dashboard-left-detail-text">
        <h4>Admin Dashboard</h4>
       <a href="mailto:{{ auth()->user()->email }}">{{ auth()->user()->email }}</a>
        {{-- Sign Out Form --}}
        <form method="POST" action="{{ route('logout') }}" style="display:inline;">
            @csrf
            <button type="submit" class="theme-btn">Sign Out</button>
        </form>
    </div>
</div>

    <div class="dashboard-left-nav">
        <ul class="dashboard-left-nav-list nav flex-column active collapse show" role="tablist">

            <!-- HOME PAGE -->
            <li class="nav-item nav-inner">
                <a class="nav-link dropdown-btn active" data-bs-toggle="collapse"
                    href="#homeDropdown">
                    Manage Website <i class="fa-solid fa-caret-down float-end"></i>
                </a>

                <ul id="homeDropdown" class="collapse nav flex-column" role="tablist">

                    
                    <li class="nav-item">
                        <a href="#ManageServices" class="nav-link" data-bs-toggle="tab" role="tab">
                            Manage Services
                        </a>
                    </li>

                   
                    <li class="nav-item">
                        <a href="#ManageBarber" class="nav-link" data-bs-toggle="tab" role="tab">
                            Manage Barber
                        </a>
                    </li>

                </ul>

            </li>

            <!-- Other Pages -->
            <li class="nav-item">
                <a href="#Time-Date" class="nav-link" data-bs-toggle="tab">Time & Date</a>
            </li>
            <li class="nav-item">
                <a href="#ServicesPage" class="nav-link" data-bs-toggle="tab">Manage Appointments</a>
            </li>
            

        </ul>
    </div>

</div>
