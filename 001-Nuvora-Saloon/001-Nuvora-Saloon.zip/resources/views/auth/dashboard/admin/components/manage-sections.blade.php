@php
$totalServices = \App\Models\Service::count();
@endphp
<div class="alert-container">
   @if(session('success'))
   <div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Success!</strong> {{ session('success') }}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>
   @endif
   @if(session('error'))
   <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> {{ session('error') }}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>
   @endif
   @if($errors->any())
   <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Please fix the following:</strong>
      <ul class="mb-0">
         @foreach($errors->all() as $error)
         <li>{{ $error }}</li>
         @endforeach
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>
   @endif
</div>
<div class="dashboard-content">
   <div class="tab-pane fade show active" id="HomePage">
      <h3>Home Page</h3>
      <p>Content for Home Page tab.</p>
   </div>
   <div class="tab-pane fade" id="ManageServices">
      <h3>Manage Services</h3>
      <div class="d-flex gap-10 mb-5">
         <a href="{{ route('admin.services.create') }}" class="theme-btn ">Add New Service</a>
         <a href="{{ $totalServices > 4 ? route('services') : route('index') }}" class="black-btn theme-btn ">
         View Services
         </a>
      </div>
      <table class="table table-bordered">
         <thead>
            <tr>
               <th>Title</th>
               <th>Description</th>
               <th>Image</th>
               <th>Actions</th>
            </tr>
         </thead>
         <tbody>
            @foreach($services as $service)
            <tr>
               <td>{{ $service->title }}</td>
               <td>{{ $service->description }}</td>
               <td>
                  @if($service->image)
                  <img src="{{ asset('storage/'.$service->image) }}" width="40" class="service-table-image" alt="">
                  @endif
               </td>
               <td>
                  <div class="service-manage">
                     <!-- Updated route names for edit & destroy -->
                     <a href="{{ route('admin.services.edit', $service->id) }}" class="theme-btn sm-btn">Edit</a>
                     <form action="{{ route('admin.services.destroy', $service->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button class="theme-btn sm-btn black-btn">Delete</button>
                     </form>
                  </div>
               </td>
            </tr>
            @endforeach
         </tbody>
      </table>
   </div>
   <div class="tab-pane fade" id="ManageBarber">
      <h3>Manage Barber</h3>
      <div class="d-flex gap-10 mb-5">
         <a href="{{ route('admin.barbers.create') }}" class="theme-btn">Add New Barber</a>
         <a href="{{ route('index') }}#barber-section" class="black-btn theme-btn">View Barber Section</a>
      </div>
      <table class="table table-bordered">
         <thead>
            <tr>
               <th>Name</th>
               <th>Designation</th>
               <th>Image</th>
               <th>Actions</th>
            </tr>
         </thead>
         <tbody>
            @foreach($barbers as $barber)
            <tr>
               <td>{{ $barber->name }}</td>
               <td>{{ $barber->designation }}</td>
               <td>
                  @if($barber->image)
                  <img src="{{ asset('storage/'.$barber->image) }}" width="20" class="barber-admin-img" alt="">
                  @endif
               </td>
               <td>
                  <div class="service-manage">
                     <a href="{{ route('admin.barbers.edit', $barber->id) }}" class="theme-btn sm-btn">Edit</a>
                     <form action="{{ route('admin.barbers.destroy', $barber->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button class="theme-btn sm-btn black-btn">Delete</button>
                     </form>
                  </div>
               </td>
            </tr>
            @endforeach
         </tbody>
      </table>
   </div>
   <!-- Other main pages -->
   <div class="tab-pane fade" id="Time-Date">
      <h3>Manage Time & Date</h3>
      <!-- Step 1: Default Working Days -->
      <div class="card mb-4">
         <div class="card-body">
            <h5>Working Days</h5>
            <p>Select the default days when the salon is open (Sat/Sun are off by default):</p>
            <div class="d-flex gap-10 flex-wrap">
               @php
               $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
               $defaultDays = ['Mon','Tue','Wed','Thu','Fri'];
               @endphp
               @foreach($days as $day)
               <div class="form-check">
                  <input class="form-check-input working-day" 
                  type="checkbox" 
                  name="working_days[]" 
                  id="day_{{ $day }}" 
                  value="{{ $day }}" 
                  @if(in_array($day, $defaultDays)) checked @endif>
                  <label class="form-check-label" for="day_{{ $day }}">{{ $day }}</label>
               </div>
               @endforeach
            </div>
         </div>
      </div>
      <!-- Step 2: Default Working Hours -->
      <div class="card mb-4">
         <div class="card-body">
            <h5>Working Hours</h5>
            <p>Set opening and closing times (applies to all working days):</p>
            <div class="d-flex gap-3 align-items-center">
               <div>
                  <label for="openTime" class="form-label">Opening Time</label>
                  <input type="time" id="openTime" class="form-control" name="opening_time" value="09:00">
               </div>
               <div>
                  <label for="closeTime" class="form-label">Closing Time</label>
                  <input type="time" id="closeTime" class="form-control" name="closing_time" value="18:00">
               </div>
            </div>
         </div>
      </div>
      <!-- Step 3: Default Breaks -->
      <div class="card mb-4">
         <div class="card-body">
            <h5>Breaks / Non-Working Hours</h5>
            <p>Add breaks (these slots will be removed from all working days):</p>
            <table class="table table-bordered" id="breakTable">
               <thead>
                  <tr>
                     <th>Start Time</th>
                     <th>End Time</th>
                     <th>Actions</th>
                  </tr>
               </thead>
               <tbody>
                  <!-- Default break rows can be added dynamically via JS -->
               </tbody>
            </table>
            <button type="button" class="btn theme-btn" id="addBreakBtn">Add Break</button>
         </div>
      </div>
      <!-- Save All Steps Button -->
      <div class="d-flex justify-content-end mt-3">
         <button type="button" class="theme-btn flex-right sm-btn" id="saveSchedule">Save</button>
      </div>
      <!-- Step 4: Month Calendar -->
      <div class="card mb-4">
         <div class="card-body">
            <h5>Month View</h5>
            <p>Weeks are automatically generated with 7 days each. Default working days are pre-checked. Sat/Sun are off.</p>
            <div id="monthCalendar">
               <!-- JS will populate month calendar checkboxes here -->
            </div>
         </div>
      </div>
      <!-- Save Button -->
      <div class="d-flex justify-content-end mt-3">
         <button type="button" class="btn theme-btn" id="saveOverridesBtn">Save Changes</button>
      </div>
   </div>
   <div class="tab-pane fade" id="ServicesPage">
      <h3>Manage Appointments</h3>
      {{-- Filter by status --}}
      <div class="row">
         <div class="col-lg-6">
            <div class="mb-3 d-flex align-items-center gap-3">
               <label for="filterStatus" class="form-label mb-0">Filter by Status:</label>
               <form method="GET" id="filterForm">
                  <select id="filterStatus" name="status" class="form-select w-auto" onchange="document.getElementById('filterForm').submit()">
                  <option value="all" {{ request('status') == 'all' ? 'selected' : '' }}>All</option>
                  <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                  <option value="confirmed" {{ request('status') == 'confirmed' ? 'selected' : '' }}>Confirmed</option>
                  <option value="cancelled" {{ request('status') == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                  <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Completed</option>
                  </select>
               </form>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="mb-3 d-flex align-items-center gap-3">
               <label for="searchUser" class="form-label mb-0">Search User:</label>
               <input type="text" id="searchUser" class="form-control w-auto" placeholder="Enter user name">
            </div>
         </div>
      </div>
      <div class="table-responsive custom-table-wrapper">
      <table class="table table-bordered table-striped custom-table">
         <thead>
            <tr>
               <th>User</th>
               <th>Email</th>
               <th>Barber</th>
               <th>Services</th>
               <th>Date</th>
               <th>Time</th>
               <th>Total Price</th>
               <th>Status</th>
               <th>Notes</th>
               <th>Actions</th>
               {{-- NEW --}}
            </tr>
         </thead>
         <tbody>
            @forelse($appointments as $app)
            <tr>
               <td>{{ $app->customer_name ?? ($app->user->name ?? 'N/A') }}</td>
               <td>{{ $app->user->email ?? 'N/A' }}</td>
               <td>{{ $app->barber->name }}</td>
               <td>
                  @php
                  $services = is_array($app->services) ? $app->services : json_decode($app->services, true);
                  @endphp
                  @foreach($services as $svc)
                  {{ $svc['name'] }} (${{ $svc['price'] }})<br>
                  @endforeach
               </td>
               <td>{{ $app->appointment_date }}</td>
               <td>{{ $app->appointment_time }}</td>
               <td>${{ $app->total_price }}</td>
               <td id="status-{{ $app->id }}">{{ ucfirst($app->status) }}</td>
               <td>{{ $app->notes }}</td>
               <td class="d-flex gap-2">
                  @if($app->status == 'pending')
                  <form action="{{ route('admin.appointments.updateStatus', $app->id) }}" method="POST" style="display:inline;">
                     @csrf
                     <input type="hidden" name="status" value="confirmed">
                     <button class="btn btn-success btn-sm" type="submit">Accept</button>
                  </form>
                  <form action="{{ route('admin.appointments.updateStatus', $app->id) }}" method="POST" style="display:inline;">
                     @csrf
                     <input type="hidden" name="status" value="cancelled">
                     <button class="btn btn-danger btn-sm" type="submit">Cancel</button>
                  </form>
                  @elseif($app->status == 'confirmed')
                  <form action="{{ route('admin.appointments.updateStatus', $app->id) }}" method="POST" style="display:inline;">
                     @csrf
                     <input type="hidden" name="status" value="completed">
                     <button class="btn btn-primary btn-sm" type="submit">Complete</button>
                  </form>
                  @endif
               </td>
            </tr>
            @empty
            <tr>
               <td colspan="9" class="text-center">No appointments found</td>
            </tr>
            @endforelse
         </tbody>
      </table>
      </div>
   </div>
</div>
</div>
<script>
   $(document).ready(function() {
       $('#searchUser').on('keyup', function() {
           let userName = $(this).val();
   
           $.ajax({
               url: "{{ route('admin.appointments.search') }}",
               method: 'GET',
               data: { user: userName },
               success: function(res) {
                   let tbody = '';
                   if(res.appointments.length > 0) {
                       res.appointments.forEach(function(app) {
                           let servicesList = '';
                           let services = typeof app.services === 'string' ? JSON.parse(app.services) : app.services;
   
                           services.forEach(function(svc) {
                               servicesList += svc.name + ' ($' + svc.price + ')<br>';
                           });
   
   tbody += `<tr>
       <td>${app.customer_name ?? (app.user ? app.user.name : 'N/A')}</td>
       <td>${app.barber.name}</td>
       <td>${servicesList}</td>
       <td>${app.appointment_date}</td>
       <td>${app.appointment_time}</td>
       <td>$${app.total_price}</td>
       <td>${app.status.charAt(0).toUpperCase() + app.status.slice(1)}</td>
       <td>${app.notes ?? ''}</td>  
       <td class="d-flex gap-2">
           ${app.status === 'pending' ? `<button class="btn btn-success btn-sm update-status" data-id="${app.id}" data-status="confirmed">Accept</button>` : ''}
           ${app.status === 'confirmed' ? `<button class="btn btn-primary btn-sm update-status" data-id="${app.id}" data-status="completed">Complete</button>` : ''}
           ${app.status !== 'cancelled' ? `<button class="btn btn-danger btn-sm update-status" data-id="${app.id}" data-status="cancelled">Cancel</button>` : ''}
       </td>
   </tr>`;
   
                       });
                   } else {
                       tbody = `<tr><td colspan="8" class="text-center">No appointments found</td></tr>`;
                   }
   
                   $('table tbody').html(tbody);
               },
               error: function(err) {
                   console.error(err);
               }
           });
       });
   });
   
      
      $(document).ready(function () {
   
   const csrfToken = $('meta[name="csrf-token"]').attr('content');
   
   // --- 1️⃣ Add/Remove Break Rows ---
   $("#addBreakBtn").click(function () {
       $("#breakTable tbody").append(`
           <tr class="break-row">
               <td><input type="time" name="break_start[]" class="form-control"></td>
               <td><input type="time" name="break_end[]" class="form-control"></td>
               <td>
                   <button type="button" class="btn btn-danger removeBreak">X</button>
               </td>
           </tr>
       `);
   });
   
   $(document).on("click", ".removeBreak", function () {
       $(this).closest(".break-row").remove();
   });
   
   // --- 2️⃣ Render Month Calendar ---
   function renderMonthCalendar(defaultWorkingDays, openingTime, closingTime, breaks = [], overrides = {}) {
      const calendarContainer = $('#monthCalendar');
      calendarContainer.empty();
   
      const today = new Date();
      const year = today.getFullYear();
      const month = today.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
   
      for (let d = 1; d <= daysInMonth; d++) {
          const dateObj = new Date(year, month, d);
          const dayName = dayNames[dateObj.getDay()];
   
          const monthStr = String(month + 1).padStart(2, '0');
          const dayStr = String(d).padStart(2, '0');
          const dateAttr = `${year}-${monthStr}-${dayStr}`;
   
          // Enabled only if default working day
          let isEnabled = defaultWorkingDays.includes(dayName);
          let isChecked = isEnabled; // checked by default
          let isDisabled = !isEnabled; // disable non-working days initially
   
          // Apply overrides if exist
          if (overrides[dateAttr]) {
              isChecked = overrides[dateAttr].is_open == 1;
              isDisabled = false; // allow admin to edit override
          }
   
          const checkbox = $(`
              <div class="form-check d-inline-block me-2 mb-2">
                  <input type="checkbox" class="form-check-input month-day" 
                         id="day-${d}" data-day-name="${dayName}" data-date="${dateAttr}"
                         ${isChecked ? 'checked' : ''} ${isDisabled ? 'disabled' : ''}>
                  <label class="form-check-label" for="day-${d}">${d} (${dayName})</label>
              </div>
          `);
   
          calendarContainer.append(checkbox);
      }
   }
   // --- 3️⃣ Save Default Working Days + Opening/Closing/Breaks ---
   const saveScheduleUrl = "{{ route('admin.schedule.store') }}";
   
   $("#saveSchedule").click(function () {
   
       // Step 1: working days
       const workingDays = $('.working-day:checked').map(function () { return $(this).val(); }).get();
   
       // Step 2: opening/closing
       const openingTime = $('#openTime').val();
       const closingTime = $('#closeTime').val();
   
       // Step 3: breaks
       const breaks = [];
       $("#breakTable tbody .break-row").each(function () {
           const start = $(this).find('input[name="break_start[]"]').val();
           const end = $(this).find('input[name="break_end[]"]').val();
           if (start && end) breaks.push({ start, end });
       });
   
       const data = {
           working_days: workingDays,
           opening_time: openingTime,
           closing_time: closingTime,
           breaks: breaks,
           _token: $('meta[name="csrf-token"]').attr('content') // CSRF token
       };
   
       // ✅ AJAX call to save schedule to database
       $.ajax({
           url: saveScheduleUrl,
           method: 'POST',
           data: data,
           success: function(res) {
               if(res.success) {
                   alert('Schedule saved to database!');
                   // Render month calendar after DB save
                   renderMonthCalendar(workingDays);
               } else {
                   alert('Failed to save schedule.');
               }
           },
           error: function(xhr) {
               console.log(xhr.responseText);
               alert('AJAX error. Check console.');
           }
       });
   
   });
   
   
   
   // --- 4️⃣ Save Overrides (Month Calendar changes) ---
   $("#saveOverridesBtn").click(function () {
       let overridesData = {};
       $(".month-day").each(function () {
           const date = $(this).data("date");
           overridesData[date] = {
               is_open: $(this).is(':checked') ? 1 : 0,
               opening_time: $('#openTime').val(),
               closing_time: $('#closeTime').val(),
               breaks: [] // optional: extend to specific day breaks
           };
       });
   
       $.ajax({
           url: '/admin/schedule/override/save',
           method: 'POST',
           data: {
               overrides: overridesData,
               _token: csrfToken
           },
           success: function (res) {
               alert('Month overrides saved successfully!');
           }
       });
   });
   
   // --- Initialize Calendar on Page Load ---
   const defaultWorkingDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
   renderMonthCalendar(defaultWorkingDays);
   
   });
   
</script>