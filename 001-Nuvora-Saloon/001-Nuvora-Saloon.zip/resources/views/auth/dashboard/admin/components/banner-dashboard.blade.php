

<!-- dashboard banner start -->
<section class="banner_sec inner-banner">
  <div class="banner-box">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="banner_text tilt" data-tilt>
            <h1>
              Welcome to your dashboard! 
            </h1>
          </div>          
        </div>
      </div>
    </div>
  </div>
</section>
<!-- dashboard banner end -->

