<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\BarberController;
use App\Http\Controllers\Admin\ScheduleController;
use App\Http\Controllers\Admin\AdminController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\Service;

/*
|--------------------------------------------------------------------------
| FRONTEND PAGES
|--------------------------------------------------------------------------
*/
Route::get('/', [HomeController::class, 'index'])->name('index');

Route::view('/aboutus', 'pages.about');
Route::view('/services', 'pages.services')->name('services');
Route::view('/service-detail', 'pages.service-detail');
Route::view('/pricing', 'pages.pricing');
Route::view('/gallery', 'pages.gallery');
Route::view('/team', 'pages.team');
Route::view('/contactus', 'pages.contact');
Route::view('/error', 'pages.404'); 

/*
|--------------------------------------------------------------------------
| AUTH ROUTES (BREEZE)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', fn() => view('pages.login'))->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store']);

    Route::get('/register', [RegisteredUserController::class, 'create'])->name('register');
    Route::post('/register', [RegisteredUserController::class, 'store']);

    Route::get('/forgot-password', [PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetLinkController::class, 'store'])->name('password.email');

    Route::get('/reset-password/{token}', [NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('/reset-password', [NewPasswordController::class, 'store'])->name('password.update');
});

Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

/*
|--------------------------------------------------------------------------
| USER DASHBOARD + PROFILE
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {

    // User Dashboard
    Route::get('/user/dashboard', function () {
        // Only allow non-admin users (role_id != 0)
        if (Auth::user()->role_id == 0) {
            abort(403, 'Unauthorized access.');
        }
        $appointments = \App\Models\Appointment::where('user_id', Auth::id())->latest()->get();
        return view('auth.dashboard.user.pages.index', compact('appointments'));
    })->name('user.dashboard');
    
    // User Cancel Appointment
    Route::post('/appointments/{id}/cancel', [AppointmentController::class, 'cancel'])->name('user.appointments.cancel');
    
    // User Edit/Update Appointment
    Route::get('/appointments/{id}/edit', [AppointmentController::class, 'edit'])->name('user.appointments.edit');
    Route::put('/appointments/{id}/update', [AppointmentController::class, 'update'])->name('user.appointments.update');

    // User profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Appointments
    Route::get('/appointment', [AppointmentController::class, 'index'])->name('appointment');
    Route::post('/appointments/store', [AppointmentController::class, 'store'])->name('appointments.store');
});

/*
|--------------------------------------------------------------------------
| ADMIN DASHBOARD + CRUD
|--------------------------------------------------------------------------
*/
Route::prefix('admin')
    ->middleware(['auth', 'admin'])
    ->name('admin.')
    ->group(function () {

        // Dashboard
        Route::get('/dashboard', function () {
            $services = Service::all();
            $barbers = \App\Models\Barber::all();

            $query = \App\Models\Appointment::with(['barber', 'user'])->latest();
            if (request()->has('status') && request('status') !== 'all') {
                $query->where('status', request('status'));
            }
            $appointments = $query->get();

            return view('auth.dashboard.admin.pages.index', compact('services', 'barbers', 'appointments'));
        })->name('dashboard');

        // Services CRUD
        Route::resource('services', ServiceController::class);

        // Barbers CRUD
        Route::get('/barbers', [BarberController::class, 'index'])->name('barbers.index');
        Route::get('/barbers/create', [BarberController::class, 'create'])->name('barbers.create');
        Route::post('/barbers/store', [BarberController::class, 'store'])->name('barbers.store');
        Route::get('/barbers/{id}/edit', [BarberController::class, 'edit'])->name('barbers.edit');
        Route::put('/barbers/{id}/update', [BarberController::class, 'update'])->name('barbers.update');
        Route::delete('/barbers/{id}', [BarberController::class, 'destroy'])->name('barbers.destroy');

        // Schedule CRUD
        Route::post('/schedule/store', [ScheduleController::class, 'store'])->name('schedule.store');
        Route::post('/schedule/override/save', [ScheduleController::class, 'saveOverrides'])->name('schedule.override.save');
        Route::get('/schedule/allowed-days', [ScheduleController::class, 'getAllowedDays'])->name('schedule.allowed-days');
    });


    // Any logged-in user can fetch schedule
Route::middleware(['auth'])->group(function () {
    Route::get('/schedule/month/{year}/{month}', [ScheduleController::class, 'getMonthSchedule'])->name('schedule.month');
});


/*
|--------------------------------------------------------------------------
| LOGIN REDIRECT (ADMIN OR USER)
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->get('/dashboard-redirect', function () {
    return Auth::user()->role_id == 0
        ? redirect()->route('admin.dashboard')
        : redirect()->route('user.dashboard');
})->name('dashboard.redirect');

/*
|--------------------------------------------------------------------------
| DEBUG / CHECK APPOINTMENTS
|--------------------------------------------------------------------------
*/
Route::get('/check-appointments', function () {
    return \App\Models\Appointment::all();
});


Route::get('/admin/appointments/search', [AdminController::class, 'searchAppointments'])
    ->name('admin.appointments.search');
Route::post('/admin/appointments/{id}/update-status', [AdminController::class, 'updateAppointmentStatus'])
    ->name('admin.appointments.updateStatus');

/*
|--------------------------------------------------------------------------
| STORAGE FALLBACK ROUTE
|--------------------------------------------------------------------------
*/
Route::get('/storage/{extra}', function ($extra) {
    $path = storage_path('app/public/' . $extra);
    if (!file_exists($path)) {
        abort(404);
    }
    return response()->file($path);
})->where('extra', '.*');


