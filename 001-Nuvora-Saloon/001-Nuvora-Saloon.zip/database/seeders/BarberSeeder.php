<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Barber;

class BarberSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $barbers = [
            [
                'name' => 'Thomas Launge',
                'designation' => 'Owner',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
            [
                'name' => 'Rayan Williams',
                'designation' => 'Stylist',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
            [
                'name' => 'John Smith',
                'designation' => 'Senior',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
        ];

        foreach ($barbers as $barber) {
            Barber::create($barber);
        }
    }
}
