<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Service;

class ServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $services = [
            [
                'title' => 'Hair Cut',
                'description' => 'Professional haircut for men and women',
                'hours' => 45,
                'price' => 25,
                'image' => null
            ],
            [
                'title' => 'Beard Trim',
                'description' => 'Perfect beard shaping and trimming',
                'hours' => 30,
                'price' => 15,
                'image' => null
            ],
            [
                'title' => 'Hair Coloring',
                'description' => 'Hair coloring service for all types',
                'hours' => 60,
                'price' => 40,
                'image' => null
            ],
        ];

        foreach ($services as $service) {
            Service::create($service);
        }
    }
}
