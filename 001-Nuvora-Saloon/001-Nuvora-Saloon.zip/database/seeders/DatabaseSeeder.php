<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Service;
use App\Models\Barber;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Default Admin
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => Hash::make('admin123'),
            'role_id' => 0,
        ]);

        // Default Normal User
        User::create([
            'name' => 'Normal User',
            'email' => 'user@example.com',
            'password' => Hash::make('user123'),
            'role_id' => 1,
        ]);

        // Default Services
        $services = [
            [
                'title' => 'Hair Cut',
                'description' => 'Professional haircut for men and women',
                'hours' => 45,
                'price' => 25,
                'image' => null
            ],
            [
                'title' => 'Beard Trim',
                'description' => 'Perfect beard shaping and trimming',
                'hours' => 30,
                'price' => 15,
                'image' => null
            ],
            [
                'title' => 'Hair Coloring',
                'description' => 'Hair coloring service for all types',
                'hours' => 60,
                'price' => 40,
                'image' => null
            ],
        ];

        foreach ($services as $service) {
            Service::create($service);
        }

        // Default Barbers
        $barbers = [
            [
                'name' => 'Thomas Launge',
                'designation' => 'Owner',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
            [
                'name' => 'Rayan Williams',
                'designation' => 'Stylist',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
            [
                'name' => 'John Smith',
                'designation' => 'Senior',
                'facebook' => null,
                'twitter' => null,
                'instagram' => null,
                'image' => null
            ],
        ];

        foreach ($barbers as $barber) {
            Barber::create($barber);
        }
        $this->call(AppointmentSeeder::class);
    }
}
