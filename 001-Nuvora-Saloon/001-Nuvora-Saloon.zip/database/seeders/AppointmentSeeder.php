<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Appointment;
use App\Models\Barber;
use App\Models\Service;
use Carbon\Carbon;
use App\Models\User;

class AppointmentSeeder extends Seeder
{
public function run(): void
{
    $barbers = Barber::all();
    $services = Service::all();

    // Make sure a user exists
    $user = User::firstOrCreate(
        ['email' => 'customer@example.com'],
        [
            'name' => 'Customer 1',
            'password' => bcrypt('password123'),
            'role_id' => 1
        ]
    );

    // Generate 10 appointments
    for ($i = 1; $i <= 10; $i++) {
        $barber = $barbers->random();
        $service = $services->random();

Appointment::create([
    'user_id' => $user->id,
    'barber_id' => $barber->id,
    'customer_name' => 'Customer ' . $i, // <- add this
    'services' => [
        [
            'id' => $service->id,
            'name' => $service->title,
            'duration' => $service->hours,
            'price' => $service->price
        ]
    ],
    'appointment_date' => \Carbon\Carbon::now()->addDays($i)->format('Y-m-d'),
    'appointment_time' => rand(9, 17) . ':00',
    'total_price' => $service->price,
    'status' => 'pending',
    'notes' => 'Seeder test appointment #' . $i,
]);

    }
}
}
