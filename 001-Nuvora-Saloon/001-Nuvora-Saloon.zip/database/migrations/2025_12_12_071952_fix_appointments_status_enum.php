<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Fix ENUM values for 'status' column
        DB::statement("ALTER TABLE `appointments` MODIFY `status` ENUM('pending', 'confirmed', 'completed', 'cancelled') NOT NULL DEFAULT 'pending'");
    }

    public function down(): void
    {
        // Rollback: revert to previous ENUM (adjust if needed)
        DB::statement("ALTER TABLE `appointments` MODIFY `status` ENUM('pending') NOT NULL DEFAULT 'pending'");
    }
};
