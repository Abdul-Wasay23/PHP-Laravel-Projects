<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('schedule_overrides', function (Blueprint $table) {
            $table->id();
            $table->date('date')->index();
            $table->boolean('is_working')->default(false);
            $table->string('opening_time')->nullable();
            $table->string('closing_time')->nullable();
            $table->json('breaks')->nullable();
            $table->string('note')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('schedule_overrides');
    }
};
