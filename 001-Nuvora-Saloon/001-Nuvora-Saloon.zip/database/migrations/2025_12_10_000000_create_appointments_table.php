<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('appointments', function (Blueprint $table) {
            $table->id();
            
            // Keep this if users are logged in
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('cascade');

            $table->foreignId('barber_id')->constrained('barbers')->onDelete('cascade');

            // Add this new column
            $table->string('customer_name')->nullable();

            $table->json('services');
            $table->date('appointment_date');
            $table->time('appointment_time');
            $table->decimal('total_price', 8, 2);
$table->enum('status', ['pending','confirmed','completed','cancelled'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('appointments');
    }
};
