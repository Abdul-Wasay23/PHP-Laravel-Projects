document.addEventListener('DOMContentLoaded', () => {
    const dropAreas = document.querySelectorAll('.drop-area');

    dropAreas.forEach(area => {
        const fileInput = area.querySelector('.file-input');
        const previewId = area.getAttribute('data-preview-id');
        const preview = document.getElementById(previewId);

        // Click on area opens file dialog
        area.addEventListener('click', () => fileInput.click());

        // File selected via dialog
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length) showPreview(fileInput.files[0], preview, fileInput);
        });

        // Drag over
        area.addEventListener('dragover', (e) => {
            e.preventDefault();
            area.style.borderColor = '#000';
        });

        // Drag leave
        area.addEventListener('dragleave', () => {
            area.style.borderColor = '#ccc';
        });

        // Drop
        area.addEventListener('drop', (e) => {
            e.preventDefault();
            area.style.borderColor = '#ccc';
            const files = e.dataTransfer.files;
            if (files.length) {
                fileInput.files = files;
                showPreview(files[0], preview, fileInput);
            }
        });
    });

    // Function to show preview and validate
    function showPreview(file, preview, input) {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/svg+xml', 'image/pjpeg'];

        if (!allowedTypes.includes(file.type)) {
            alert('Only jpeg, png, jpg, gif, svg files are allowed');
            input.value = '';
            return;
        }

        if (file.size > 2 * 1024 * 1024) { // 2MB limit
            alert('Image size should be less than 2MB');
            input.value = '';
            return;
        }

        preview.src = URL.createObjectURL(file);
        preview.style.display = 'block';
    }
});




// This js is for tabs
document.addEventListener('DOMContentLoaded', function () {
    // Get all tab links
    const tabLinks = document.querySelectorAll('.nav-link'); // assume aapke tabs nav-link class me hain
    const tabPanes = document.querySelectorAll('.tab-pane');

    // Load last active tab from localStorage
    const lastActiveTab = localStorage.getItem('activeTab');
    if (lastActiveTab) {
        // Remove active from all tabs & panes
        tabLinks.forEach(link => link.classList.remove('active'));
        tabPanes.forEach(pane => pane.classList.remove('show', 'active'));

        // Activate the stored tab
        const activeLink = document.querySelector(`.nav-link[href="${lastActiveTab}"]`);
        const activePane = document.querySelector(lastActiveTab);

        if (activeLink && activePane) {
            activeLink.classList.add('active');
            activePane.classList.add('show', 'active');
        }
    }

    // Listen for tab clicks
    tabLinks.forEach(link => {
        link.addEventListener('click', function () {
            localStorage.setItem('activeTab', this.getAttribute('href'));
        });
    });
});


