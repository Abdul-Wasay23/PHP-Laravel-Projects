


// This js is for menu
$(document).on("click", ".hamburger-menu", function () {
  $("body").toggleClass("hamburger-navigation-active");
  $(".hamburger-menu svg").toggleClass("opened");
});
// This js is for menu

// This js is for tilt animation
$(document).ready(function () {
  $(".tilt").tilt({
    maxGlare: 1,
    maxTilt: 3,
    transition: true,
  });
});
// This js is for tilt animation

// This js is for video play and pause
document.querySelectorAll(".hour-card").forEach((card) => {
  const video = card.querySelector(".hour-video");
  const playPauseBtn = card.querySelector(".play-pause");

  playPauseBtn.addEventListener("click", (e) => {
    e.preventDefault();

    if (video.paused) {
      document.querySelectorAll(".hour-video").forEach((v) => v.pause());
      document
        .querySelectorAll(".hour-card")
        .forEach((c) => c.classList.remove("playing"));

      video.play();
      card.classList.add("playing");
    } else {
      video.pause();
      card.classList.remove("playing");
    }
  });

  video.addEventListener("ended", () => {
    card.classList.remove("playing");
  });
});
// This js is for video play and pause

// this js is for aos animation
function handleAOS() {
  if (typeof AOS !== "undefined") {
    if (window.innerWidth > 768) {
      AOS.init();
    } else {
      const aosElements = document.querySelectorAll("[data-aos]");
      aosElements.forEach((el) => {
        el.removeAttribute("data-aos");
        el.style.opacity = 1;
        el.style.transform = "none";
      });
    }
  } else {
    console.warn("AOS is not loaded.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  handleAOS();

  window.addEventListener("resize", () => {
    handleAOS();
  });
});
// this js is for aos animation

// this js is for loader
$(window).on("load", function () {
  var width = 100,
    perfData = window.performance.timing,
    EstimatedTime = -(perfData.loadEventEnd - perfData.navigationStart),
    time = parseInt((EstimatedTime / 1000) % 60) * 60;

  $(".loadbar").animate({ width: width + "%" }, time);

  function animateValue(id, start, end, duration) {
    var range = end - start,
      current = start,
      increment = end > start ? 1 : -1,
      stepTime = Math.abs(Math.floor(duration / range)),
      obj = $(id);

    var timer = setInterval(function () {
      current += increment;
      $(obj).text(current + "%");
      if (current == end) clearInterval(timer);
    }, stepTime);
  }

  setTimeout(function () {
    $("body").addClass("page-loaded");
  }, time);

  if ($.fn.counterUp) {
    $(".counter1").counterUp({ delay: 10 });
    $(".counter").counterUp({ delay: 10 });
  }
});

// this js is for loader

// Testi slider start
$(".testi-slider").slick({
  arrows: true,
  dots: false,
  infinite: true,
  speed: 300,
  autoplay: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1100,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
      },
    },
    {
      breakpoint: 900,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      },
    },
    {
      breakpoint: 500,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      },
    },
    {
      breakpoint: 400,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows: false,
      },
    },
  ],
});
setInterval(function () {
  let next_img = $(".testi-box.slick-slide.slick-current")
    .next()
    .find(".testi-img>img")
    .attr("src");
  let prev_img = $(".testi-box.slick-slide.slick-current")
    .prev()
    .find(".testi-img>img")
    .attr("src");
  $(".testi-slider button.slick-prev").css(
    "background-image",
    "url(" + prev_img + ")"
  );
  $(".testi-slider button.slick-next").css(
    "background-image",
    "url(" + next_img + ")"
  );
}, 100);
var $status = $(".start_number1");
var $slickElement = $(".testi-slider");
$slickElement.on(
  "init reInit afterChange",
  function (event, slick, currentSlide, nextSlide) {
    var i = (currentSlide ? currentSlide : 0) + 1;
    $status.text("0" + i + "");
  }
);
var $slider = $(".testi-slider");
var $progressBar = $(".progress3");
var $progressBarLabel = $(".slider__label");
$slider.on("beforeChange", function (event, slick, currentSlide, nextSlide) {
  var calc = (nextSlide / (slick.slideCount - 1)) * 100;
  $progressBar
    .css("background-size", calc + "% 100%")
    .attr("aria-valuenow", calc);
  $progressBarLabel.text(calc + "% completed");
});
// Testi slider  end

// wow animation js
$(function () {
  new WOW().init();
});
// wow animation js

// this js is for Active Menu
function highlightActiveMenu() {
  // Get current page filename
  let currentPage = window.location.pathname.split("/").pop().toLowerCase();

  if (
    currentPage === "" ||
    currentPage === "index" ||
    currentPage === "index.html"
  ) {
    currentPage = "index.html";
  }

  $("#menu li a").each(function () {
    let linkPage = $(this).attr("href").toLowerCase();

    if (linkPage === currentPage) {
      $(this).addClass("active");
    } else {
      $(this).removeClass("active");
    }
  });
}
// this js is for Active Menu

// Password Hide Start
function togglePasswordVisibility(toggleButton) {
  $(toggleButton).toggleClass("fa-eye fa-eye-slash");
  var input = $($(toggleButton).attr("toggle"));
  if (input.attr("type") === "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
}
// Attach event listener
$(document).on("click", ".toggle-password", function () {
  togglePasswordVisibility(this);
});
// Password Hide End
